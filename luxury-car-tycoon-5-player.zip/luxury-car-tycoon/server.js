const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const MAX_PLAYERS = 5;
const STARTING_CASH = 250000;
const rooms = new Map();

const CARS = [
  { id:"urus", name:"Lamborghini Urus", brand:"LAMBORGHINI", price:85000, resale:112000, tier:"SPORT SUV", emoji:"🚙", color:"#b8a36a" },
  { id:"911", name:"Porsche 911 Turbo S", brand:"PORSCHE", price:145000, resale:187000, tier:"SPORT", emoji:"🏎️", color:"#d6d9df" },
  { id:"r8", name:"Audi R8 V10", brand:"AUDI", price:165000, resale:214000, tier:"SUPERCAR", emoji:"🏎️", color:"#9eabb7" },
  { id:"aventador", name:"Lamborghini Aventador", brand:"LAMBORGHINI", price:310000, resale:395000, tier:"SUPERCAR", emoji:"🏎️", color:"#c7a44a" },
  { id:"488", name:"Ferrari 488 Pista", brand:"FERRARI", price:340000, resale:435000, tier:"SUPERCAR", emoji:"🏎️", color:"#bd4744" },
  { id:"720s", name:"McLaren 720S", brand:"MCLAREN", price:390000, resale:498000, tier:"SUPERCAR", emoji:"🏎️", color:"#cf743f" },
  { id:"gt3", name:"Porsche 911 GT3 RS", brand:"PORSCHE", price:420000, resale:535000, tier:"TRACK", emoji:"🏎️", color:"#d8d8d0" },
  { id:"sf90", name:"Ferrari SF90 Stradale", brand:"FERRARI", price:620000, resale:790000, tier:"HYPERCAR", emoji:"🏎️", color:"#b53d3d" },
  { id:"chiron", name:"Bugatti Chiron", brand:"BUGATTI", price:1900000, resale:2390000, tier:"HYPERCAR", emoji:"🏎️", color:"#4b7194" },
  { id:"ghost", name:"Rolls-Royce Ghost", brand:"ROLLS-ROYCE", price:420000, resale:535000, tier:"LUXURY", emoji:"🚘", color:"#b8b4a9" },
  { id:"phantom", name:"Rolls-Royce Phantom", brand:"ROLLS-ROYCE", price:620000, resale:790000, tier:"LUXURY", emoji:"🚘", color:"#d2c8ae" },
  { id:"revuelto", name:"Lamborghini Revuelto", brand:"LAMBORGHINI", price:720000, resale:915000, tier:"HYPERCAR", emoji:"🏎️", color:"#a4a84c" }
];

function makeRoom(code) {
  return { code, players: {}, createdAt: Date.now(), feed: [] };
}
function publicRoom(room) {
  const players = Object.values(room.players).map(p => ({
    id:p.id, name:p.name, cash:p.cash, level:p.level, showroom:p.showroom,
    inventory:p.inventory, totalSales:p.totalSales, reputation:p.reputation,
    online:true
  }));
  return { code:room.code, players, cars:CARS, feed:room.feed.slice(-12) };
}
function emitRoom(room) {
  io.to(room.code).emit("state", publicRoom(room));
}
function addFeed(room, message) {
  room.feed.push({ message, at: Date.now() });
  if (room.feed.length > 30) room.feed.shift();
}
function playerNetWorth(p) {
  const stock = p.inventory.reduce((sum, item) => {
    const car = CARS.find(c => c.id === item.carId);
    return sum + (car ? Math.round(car.price * 0.85) : 0);
  }, 0);
  return p.cash + stock + p.showroom * 60000;
}
function cleanName(name) {
  return String(name || "Driver").replace(/[<>]/g, "").trim().slice(0, 16) || "Driver";
}

io.on("connection", socket => {
  socket.on("join", ({ code, name } = {}, callback = () => {}) => {
    code = String(code || "ELITE5").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10) || "ELITE5";
    let room = rooms.get(code);
    if (!room) { room = makeRoom(code); rooms.set(code, room); }
    if (Object.keys(room.players).length >= MAX_PLAYERS) {
      callback({ ok:false, error:"This room is full. It already has 5 players." });
      return;
    }
    const player = {
      id:socket.id, name:cleanName(name), cash:STARTING_CASH, level:1, showroom:1,
      inventory:[], totalSales:0, reputation:50, joinedAt:Date.now()
    };
    room.players[socket.id] = player;
    socket.join(code);
    socket.data.room = code;
    addFeed(room, `${player.name} joined the dealership district.`);
    callback({ ok:true, code, playerId:socket.id });
    emitRoom(room);
  });

  socket.on("buyCar", ({ carId } = {}, callback = () => {}) => {
    const room = rooms.get(socket.data.room);
    const p = room && room.players[socket.id];
    const car = CARS.find(c => c.id === carId);
    if (!p || !car) return callback({ ok:false, error:"That car isn't available." });
    const capacity = 2 + (p.showroom - 1) * 2;
    if (p.inventory.length >= capacity) return callback({ ok:false, error:"Your showroom is full. Upgrade it to stock more cars." });
    if (p.cash < car.price) return callback({ ok:false, error:"Not enough cash for this car." });
    p.cash -= car.price;
    p.inventory.push({ uid:Math.random().toString(36).slice(2,10), carId:car.id, boughtAt:Date.now() });
    addFeed(room, `${p.name} stocked a ${car.name}.`);
    callback({ ok:true });
    emitRoom(room);
  });

  socket.on("sellCar", ({ uid } = {}, callback = () => {}) => {
    const room = rooms.get(socket.data.room);
    const p = room && room.players[socket.id];
    if (!p) return callback({ ok:false, error:"Player not found." });
    const index = p.inventory.findIndex(x => x.uid === uid);
    if (index < 0) return callback({ ok:false, error:"That car is no longer in your stock." });
    const item = p.inventory[index];
    const car = CARS.find(c => c.id === item.carId);
    const bonus = Math.round((p.showroom - 1) * 0.025 * car.resale);
    const payout = car.resale + bonus;
    p.inventory.splice(index, 1);
    p.cash += payout;
    p.totalSales += 1;
    p.reputation = Math.min(100, p.reputation + 2);
    addFeed(room, `${p.name} sold a ${car.name} for $${payout.toLocaleString("en-US")}.`);
    callback({ ok:true, payout });
    emitRoom(room);
  });

  socket.on("upgrade", (_, callback = () => {}) => {
    const room = rooms.get(socket.data.room);
    const p = room && room.players[socket.id];
    if (!p) return callback({ ok:false, error:"Player not found." });
    const cost = 175000 * p.showroom;
    if (p.cash < cost) return callback({ ok:false, error:`You need $${cost.toLocaleString("en-US")} for the next showroom upgrade.` });
    p.cash -= cost;
    p.showroom += 1;
    p.level = p.showroom;
    addFeed(room, `${p.name} upgraded their showroom to level ${p.showroom}.`);
    callback({ ok:true });
    emitRoom(room);
  });

  socket.on("disconnect", () => {
    const code = socket.data.room;
    const room = code && rooms.get(code);
    if (!room || !room.players[socket.id]) return;
    const name = room.players[socket.id].name;
    delete room.players[socket.id];
    addFeed(room, `${name} left the district.`);
    if (Object.keys(room.players).length === 0) rooms.delete(code);
    else emitRoom(room);
  });
});

app.get("/health", (_, res) => res.json({ ok:true, rooms:rooms.size }));
server.listen(PORT, () => console.log(`Luxury Car Tycoon running on port ${PORT}`));