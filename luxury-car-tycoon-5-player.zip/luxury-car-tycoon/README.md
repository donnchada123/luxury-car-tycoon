# ÉLITE MOTORS — Luxury Car Tycoon (5-player online starter)

A browser-based, five-player dealership tycoon. Players join the same room code from different devices, buy and sell cars, upgrade showrooms, and compete on a live leaderboard.

## Run locally

1. Install Node.js 18 or newer.
2. Unzip this project.
3. Open a terminal in the project folder.
4. Run:

   ```bash
   npm install
   npm start
   ```

5. Open `http://localhost:3000`.

To test with multiple devices on the same Wi-Fi, open the game using your computer's local network IP address (for example `http://192.168.1.20:3000`) and allow the server through your firewall.

## Put it online for friends

This project needs a Node.js host for real online multiplayer. One straightforward route is Render:

1. Create a GitHub account and a new repository.
2. Upload the contents of this folder to the repository.
3. Create a new **Web Service** in Render and connect that repository.
4. Set **Build Command** to `npm install`.
5. Set **Start Command** to `npm start`.
6. Deploy. Share the resulting `https://...onrender.com` URL and the same room code (default `ELITE5`) with up to four friends.

The server uses in-memory rooms: room/player state resets when the server restarts or redeploys. This starter does not yet include accounts, persistent saves, chat, anti-cheat hardening, or payment systems. Keep the server running while players are connected.

## Game rules

- Each player starts with $250,000.
- Each showroom starts at level 1 and can hold two cars.
- Every showroom upgrade costs $175,000 multiplied by the current showroom level and adds two stock spaces.
- Cars sell for their listed resale value; showroom upgrades add a small resale bonus.
- Rooms allow up to five simultaneous players.

## Important

This is a playable multiplayer starter, not a finished commercial game. Before public launch, add persistent storage, authentication, rate limits, moderation/reporting, stronger server validation, and production monitoring. Vehicle names are used for a fictional game; the project is not affiliated with any car manufacturer.
